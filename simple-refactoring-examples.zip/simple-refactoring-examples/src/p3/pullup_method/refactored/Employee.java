package p3.pullup_method.refactored;

public class Employee {

   private String name;

   String getName() {
    	return this.name;
    }

}
