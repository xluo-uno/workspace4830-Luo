package p6.form_template_method1.refactored;

public class Service {
   public void beginTask() {
   }

   public void sendMessage() {
   }

   public void endTask() {
   }

   public void saveMessage() {
   }

   public void receiveMessage() {
   }
}
